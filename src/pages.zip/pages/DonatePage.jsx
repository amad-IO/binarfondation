import { ArrowRight, CircleDollarSign, HandHeart, ShieldCheck } from 'lucide-react';
import PageHeader from '../components/PageHeader';
import ImpactBanner from '../page-sections/ImpactBanner';
import SupportBanner from '../page-sections/SupportBanner';

const supportWays = [
    { title: 'Donasi publik', description: 'Dukung kebutuhan program dan kegiatan lapangan.', icon: CircleDollarSign },
    { title: 'Kemitraan', description: 'Buka peluang kolaborasi jangka panjang.', icon: HandHeart },
    { title: 'Kepercayaan', description: 'Bantu menjaga ruang aman dan berkelanjutan.', icon: ShieldCheck },
];

const DonatePage = () => {
    return (
        <>
            <PageHeader
                eyebrow="Donasi"
                title="Dukung gerakan yang memberi ruang aman untuk pulih"
                description="Kontribusimu membantu Binar menjaga program, edukasi, dan aksi sosial tetap berjalan untuk anak dan remaja."
            />

            <section className="w-full bg-white pb-8 lg:pb-12">
                <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 lg:gap-6">
                        {supportWays.map((way) => {
                            const Icon = way.icon;

                            return (
                                <div key={way.title} className="rounded-[1.5rem] border border-slate-100 bg-[#FFFDF5] p-5 lg:p-6 shadow-sm">
                                    <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-2xl bg-[#FCD368]/40 text-slate-800">
                                        <Icon size={20} />
                                    </div>
                                    <h2 className="text-lg font-bold text-slate-900">{way.title}</h2>
                                    <p className="mt-2 text-sm leading-relaxed text-slate-500">{way.description}</p>
                                </div>
                            );
                        })}
                    </div>

                    <div className="mt-6 rounded-[2rem] bg-[#FFF4D2] p-6 lg:p-8 shadow-sm flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                        <div>
                            <p className="text-sm font-semibold uppercase tracking-[0.24em] text-slate-700 mb-2">Arah page</p>
                            <h2 className="text-2xl font-bold text-slate-900">Kontribusi kecil tetap berarti besar</h2>
                        </div>
                        <a href="/kontak" className="inline-flex items-center justify-center rounded-full bg-slate-900 px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-slate-800">
                            Konsultasi Dukungan <ArrowRight size={16} className="ml-2" />
                        </a>
                    </div>
                </div>
            </section>

            <ImpactBanner />
            <SupportBanner />
        </>
    );
};

export default DonatePage;