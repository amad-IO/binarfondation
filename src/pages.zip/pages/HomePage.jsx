import { Link } from 'react-router-dom';
import { ArrowRight, BookOpenText, HeartHandshake, Info, Users } from 'lucide-react';
import Hero from '../page-sections/Hero';
import ImpactBanner from '../page-sections/ImpactBanner';

const quickLinks = [
    {
        to: '/tentang-kami',
        label: 'Tentang Kami',
        description: 'Lihat visi, misi, dan nilai yang jadi dasar gerakan Binar.',
        icon: Info,
    },
    {
        to: '/program',
        label: 'Program',
        description: 'Kenali rangkaian program yang mendampingi anak dan remaja.',
        icon: BookOpenText,
    },
    {
        to: '/relawan',
        label: 'Relawan',
        description: 'Cari tahu cara bergabung dan berkontribusi bersama tim Binar.',
        icon: Users,
    },
    {
        to: '/donasi',
        label: 'Donasi',
        description: 'Dukung gerakan kebaikan lewat kontribusi yang berdampak.',
        icon: HeartHandshake,
    },
];

const HomePage = () => {
    return (
        <>
            <Hero />

            <section className="w-full py-14 lg:py-20 bg-white">
                <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex flex-col gap-4 mb-8 lg:mb-10 max-w-3xl">
                        <span className="inline-flex w-max items-center rounded-full bg-blue-50 px-3 py-1 text-[11px] font-bold uppercase tracking-[0.28em] text-blue-600">
                            Jelajahi Halaman
                        </span>
                        <h2 className="text-2xl sm:text-3xl lg:text-[2.5rem] font-extrabold tracking-tight text-slate-900">
                            Pilih bagian yang ingin kamu buka duluan.
                        </h2>
                        <p className="text-slate-500 text-base lg:text-lg leading-relaxed">
                            Struktur situs sekarang dipisah menjadi beberapa page supaya navigasi lebih jelas, tapi tetap memakai bahasa visual yang sama.
                        </p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4 lg:gap-6">
                        {quickLinks.map((item) => {
                            const Icon = item.icon;

                            return (
                                <Link
                                    key={item.to}
                                    to={item.to}
                                    className="group rounded-[1.75rem] border border-slate-100 bg-white p-5 lg:p-6 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-blue-900/5"
                                >
                                    <div className="flex items-center justify-between gap-4 mb-5">
                                        <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-blue-50 text-blue-600">
                                            <Icon size={22} />
                                        </div>
                                        <ArrowRight className="text-slate-300 transition-transform duration-300 group-hover:translate-x-1 group-hover:text-blue-600" size={18} />
                                    </div>
                                    <h3 className="text-lg font-bold text-slate-900 mb-2">{item.label}</h3>
                                    <p className="text-sm leading-relaxed text-slate-500">{item.description}</p>
                                </Link>
                            );
                        })}
                    </div>
                </div>
            </section>

            <ImpactBanner />
        </>
    );
};

export default HomePage;