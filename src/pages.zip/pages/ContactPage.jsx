import { 
    ArrowRight, Mail, PhoneCall, MessageSquare, 
    MessageSquareText, MapPin, ExternalLink,
    Camera, PlayCircle, Heart, AlertTriangle, Lightbulb 
} from 'lucide-react';
import PageHeader from '../components/PageHeader';

const SOCIAL_MEDIA = [
    { title: 'Instagram', value: '@binar.foundation', href: 'https://www.instagram.com/binar.community', icon: Camera },
    { title: 'TikTok', value: '@binar.foundation', href: 'https://www.tiktok.com/@binar.community', icon: MessageSquare },
    { title: 'YouTube', value: 'binar foundation', href: 'https://www.youtube.com', icon: PlayCircle },
];

const CONTACT_ITEMS = [
    { title: 'Merchandise Email', value: 'binarfoundation1@gmail.com', href: 'mailto:binarfoundation1@gmail.com', icon: Mail },
    { title: 'Contact Person', value: '0823 8451 6469 (Elsa)', href: 'tel:082384516469', icon: PhoneCall },
];

const COLLABORATION_CONTACTS = [
    { name: 'Elsa Nabila', phone: '0823 8451 6469', role: 'PJ Kolaborasi Binar Foundation' },
    { name: 'Lulu', phone: '0821 8310 0744', role: 'PJ Kolaborasi Binar Chapter' },
    { name: 'Nabila Cahya', phone: '0856 4833 0433', role: 'PJ Kolaborasi Binar Chapter' },
];

const OFFICE_ADDRESSES = [
    {
        title: 'Binar Pusat',
        address: 'Jl. Purwodadi Ujung, Kel. Sialangmunggu, Kec. Tuah Madani, Kota Pekanbaru, Provinsi Riau',
        gmaps: 'https://maps.google.com'
    },
    {
        title: 'Binar Chapter Jatim',
        address: 'Pasar Burung Gang Dolly, Kel. Putat Jaya, Kec. Sawahan, Kota Surabaya, Provinsi Jawa Timur',
        gmaps: 'https://maps.google.com'
    }
];

const ContactPage = () => {
    return (
        <>
            <PageHeader
                eyebrow="Kontak"
                title="Saluran komunikasi dan kolaborasi BINAR FOUNDATION"
                description="Halaman ini memuat media sosial, kontak merchandise, jalur kolaborasi resmi, serta wadah aspirasi untuk terhubung dengan tim Binar."
            />

            <section className="w-full pb-20 lg:pb-28 bg-slate-50/30">
                <div className="container mx-auto px-4 sm:px-6 lg:px-8 space-y-12 lg:space-y-16">
                    
                    {/* GRID ATAS: 3-KOLOM ASIMETRIS (PADAT & SANGAT PROFESIONAL) */}
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 pt-8">
                        
                        {/* KOLOM 1: SOSIAL MEDIA */}
                        <div className="rounded-2xl border border-slate-100 bg-white p-6 shadow-sm flex flex-col justify-between">
                            <div>
                                <div className="border-b border-slate-100 pb-3 mb-4">
                                    <p className="text-xs font-bold uppercase tracking-[0.15em] text-blue-600 mb-0.5">Jejaring Sosial</p>
                                    <h3 className="text-base font-extrabold text-slate-900">Sosial Media Resmi</h3>
                                </div>
                                <div className="space-y-2.5">
                                    {SOCIAL_MEDIA.map((social) => {
                                        const Icon = social.icon;
                                        return (
                                            <a key={social.title} href={social.href} target="_blank" rel="noopener noreferrer" className="flex items-center justify-between gap-3 rounded-xl border border-slate-100 bg-slate-50/50 p-3 transition-all hover:border-blue-100 hover:bg-blue-50/20 group">
                                                <div className="flex items-center gap-3">
                                                    <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-white text-blue-600 border border-slate-100 shadow-sm">
                                                        <Icon size={16} className="stroke-[2.25]" />
                                                    </span>
                                                    <div>
                                                        <p className="font-bold text-xs text-slate-900 leading-tight">{social.title}</p>
                                                        <p className="text-[11px] text-slate-500 mt-0.5">{social.value}</p>
                                                    </div>
                                                </div>
                                                <ArrowRight className="text-slate-300 transition-transform group-hover:translate-x-0.5" size={14} />
                                            </a>
                                        );
                                    })}
                                </div>
                            </div>
                            <p className="text-[11px] text-slate-400 mt-6 leading-relaxed">
                                Ikuti pembaruan aktivitas harian kami di berbagai platform media sosial di atas.
                            </p>
                        </div>

                        {/* KOLOM 2: CONTACT & MERCHANDISE */}
                        <div className="rounded-2xl border border-slate-100 bg-white p-6 shadow-sm flex flex-col justify-between">
                            <div>
                                <div className="border-b border-slate-100 pb-3 mb-4">
                                    <p className="text-xs font-bold uppercase tracking-[0.15em] text-blue-600 mb-0.5">Layanan Langsung</p>
                                    <h3 className="text-base font-extrabold text-slate-900">Merchandise & Kontak</h3>
                                </div>
                                <div className="space-y-2.5">
                                    {CONTACT_ITEMS.map((item) => {
                                        const Icon = item.icon;
                                        return (
                                            <a key={item.title} href={item.href} className="flex items-center justify-between gap-3 rounded-xl border border-slate-100 bg-slate-50/50 p-3 transition-all hover:border-blue-100 hover:bg-blue-50/20 group">
                                                <div className="flex items-center gap-3">
                                                    <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-white text-blue-600 border border-slate-100 shadow-sm">
                                                        <Icon size={16} className="stroke-[2.25]" />
                                                    </span>
                                                    <div>
                                                        <p className="font-bold text-xs text-slate-900 leading-tight">{item.title}</p>
                                                        <p className="text-[11px] text-slate-500 mt-0.5">{item.value}</p>
                                                    </div>
                                                </div>
                                                <ArrowRight className="text-slate-300 transition-transform group-hover:translate-x-0.5" size={14} />
                                            </a>
                                        );
                                    })}
                                </div>
                            </div>
                            <p className="text-[11px] text-slate-400 mt-6 leading-relaxed">
                                Hubungi untuk pemesanan cinderamata resmi atau pusat informasi narahubung utama.
                            </p>
                        </div>

                        {/* KOLOM 3: FORUM BI-BETTER (DIPERBADAT & DIKEMAS PREMIUM) */}
                        <div className="rounded-2xl border border-slate-200 bg-gradient-to-b from-white to-blue-50/10 p-6 shadow-sm flex flex-col justify-between md:col-span-2 lg:col-span-1">
                            <div className="space-y-4">
                                <div className="flex items-center gap-3 border-b border-slate-100 pb-3">
                                    <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                                        <MessageSquareText size={18} className="stroke-[2.25]" />
                                    </span>
                                    <div>
                                        <p className="text-xs font-bold uppercase tracking-[0.15em] text-blue-600 mb-0.5">Suara Pengguna</p>
                                        <h3 className="text-base font-extrabold text-slate-900">Hubungan Komunitas</h3>
                                    </div>
                                </div>
                                <p className="text-xs leading-relaxed text-slate-500">
                                    Suara Anda berharga bagi kami. Salurkan ulasan, pengaduan masalah internal, kritik konstruktif, atau saran program melalui platform resmi **Bi-Better**.
                                </p>
                                <div className="space-y-1.5 pt-1">
                                    <div className="flex items-center gap-2 text-[11px] text-slate-600">
                                        <Heart size={12} className="text-rose-500 shrink-0" />
                                        <span>Apresiasi & Ulasan Gerakan</span>
                                    </div>
                                    <div className="flex items-center gap-2 text-[11px] text-slate-600">
                                        <AlertTriangle size={12} className="text-amber-500 shrink-0" />
                                        <span>Pengaduan & Kendala Sistem</span>
                                    </div>
                                    <div className="flex items-center gap-2 text-[11px] text-slate-600">
                                        <Lightbulb size={12} className="text-emerald-500 shrink-0" />
                                        <span>Kritik & Saran Strategis</span>
                                    </div>
                                </div>
                            </div>
                            <div className="pt-4">
                                <a 
                                    href="https://bit.ly/BiBetter" 
                                    target="_blank" 
                                    rel="noopener noreferrer"
                                    className="inline-flex w-full items-center justify-center gap-2 bg-blue-600 text-white font-semibold text-xs px-4 py-3 rounded-xl hover:bg-blue-700 transition shadow-sm group"
                                >
                                    Isi Formulir Bi-Better 
                                    <ExternalLink size={13} className="transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                                </a>
                            </div>
                        </div>

                    </div>

                    {/* SECTION 2: LOKASI & ALAMAT KANTOR */}
                    <div className="space-y-4">
                        <div className="flex flex-col border-b border-slate-200 pb-3">
                            <p className="text-xs font-bold uppercase tracking-[0.15em] text-blue-600">Sekretariat Resmi</p>
                            <h2 className="text-lg lg:text-xl font-extrabold text-slate-900 mt-0.5">Lokasi & Alamat Kantor</h2>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                            {OFFICE_ADDRESSES.map((office) => (
                                <div key={office.title} className="rounded-2xl border border-slate-100 bg-white p-5 shadow-sm flex items-start gap-4 hover:border-slate-200 transition-colors">
                                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-slate-50 text-blue-600 border border-slate-100">
                                        <MapPin size={18} className="stroke-[2.25]" />
                                    </div>
                                    <div className="space-y-1">
                                        <h3 className="font-extrabold text-sm text-slate-900">{office.title}</h3>
                                        <p className="text-xs text-slate-500 leading-relaxed">{office.address}</p>
                                        <a href={office.gmaps} target="_blank" rel="noopener noreferrer" className="inline-flex items-center text-xs text-blue-600 font-semibold hover:underline pt-2 group">
                                            Buka Rute Navigasi <ArrowRight size={12} className="ml-1 transition-transform group-hover:translate-x-0.5" />
                                        </a>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* SECTION 3: SOP KOLABORASI */}
                    <div className="rounded-2xl border border-slate-100 bg-white p-6 lg:p-8 shadow-sm space-y-6">
                        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between border-b border-slate-100 pb-4 gap-4">
                            <div>
                                <p className="text-xs font-bold uppercase tracking-[0.15em] text-blue-600">Prosedur Kerja Sama</p>
                                <h2 className="text-lg lg:text-xl font-extrabold text-slate-900 mt-0.5">SOP Kolaborasi Kemitraan</h2>
                            </div>
                            <a href="mailto:binarfoundation1@gmail.com" className="inline-flex items-center justify-center rounded-xl bg-blue-600 px-4 py-2.5 text-xs font-semibold text-white transition-colors hover:bg-blue-700 shadow-sm shrink-0 group">
                                Ajukan Aliansi Via Email <Mail size={14} className="ml-2 transition-transform group-hover:scale-110" />
                            </a>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            {COLLABORATION_CONTACTS.map((person) => (
                                <div key={person.name} className="rounded-xl bg-slate-50/50 p-4 border border-slate-100 shadow-2xs transition-all hover:bg-white hover:border-blue-200">
                                    <span className="inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wide bg-blue-50 text-blue-700">
                                        {person.role}
                                    </span>
                                    <h3 className="mt-2.5 text-sm font-extrabold text-slate-900">{person.name}</h3>
                                    <p className="mt-1 text-xs text-slate-500 font-medium tracking-wide">{person.phone}</p>
                                </div>
                            ))}
                        </div>

                        <div className="p-4 rounded-xl bg-slate-50 border border-slate-100/70 text-xs leading-relaxed text-slate-500">
                            <strong>Catatan Alur:</strong> Hubungi terlebih dahulu Penanggung Jawab (PJ) resmi di atas sesuai dengan klasifikasi wilayah kerja sama Anda. Penyesuaian prosedur ini dilakukan demi efisiensi dan transparansi alur birokrasi kemitraan Binar Foundation.
                        </div>
                    </div>

                </div>
            </section>
        </>
    );
};

export default ContactPage;