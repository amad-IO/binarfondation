import { ArrowRight, BadgeCheck, Heart, Landmark, Sparkles, ShieldCheck, Users } from 'lucide-react';
import PageHeader from '../components/PageHeader';

const vision = 'Mewujudkan generasi muda Indonesia yang sehat mental, bertumbuh, dan mampu memberdayakan diri serta lingkungannya secara berkelanjutan.';

const missions = [
    'Menyediakan ruang edukasi dan layanan kesehatan mental yang inklusif, aman, dan mudah diakses.',
    'Meningkatkan kesadaran kesehatan mental melalui diskusi terbuka dan pendampingan empatik berbasis komunitas.',
    'Mendorong proses tumbuh dan pulih bersama melalui dukungan emosional, sosial, spiritual, dan konseling sebaya.',
    'Menghadirkan program pendidikan untuk anak marginal yang mengintegrasikan akademik, karakter, dan kesehatan mental.',
    'Mengembangkan gerakan kolaboratif ke berbagai daerah secara berkelanjutan.',
];

const values = [
    { title: 'Nilai moral', description: 'Menjunjung nilai-nilai baik yang diajarkan dalam agama dan masyarakat.', icon: Landmark },
    { title: 'Etika', description: 'Berperilaku baik dan terdidik yang layak untuk dicontoh.', icon: ShieldCheck },
    { title: 'Kebersamaan', description: 'Tumbuh bersama dalam semangat saling menguatkan.', icon: Users },
    { title: 'Empati', description: 'Saling memahami, mendengar, dan menguatkan tanpa menghakimi.', icon: Heart },
    { title: 'Integritas', description: 'Jujur, bertanggung jawab, dan amanah dalam menjalankan peran.', icon: BadgeCheck },
    { title: 'Keberlanjutan', description: 'Program dibuat terarah, konsisten, dan terus berkembang.', icon: Sparkles },
];

const AboutPage = () => {
    return (
        <>
            <PageHeader
                eyebrow="Tentang BINAR FOUNDATION"
                title="BINAR FOUNDATION"
                description="Nomor AHU-0006853.AH.01.04.Tahun 2026"
            />

            <section className="w-full bg-white pb-8 lg:pb-12">
                <div className="container mx-auto px-4 sm:px-6 lg:px-8 space-y-6 lg:space-y-8">
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 lg:gap-6">
                        <div className="rounded-[1.75rem] border border-slate-100 bg-[#F8FAFC] p-6 lg:p-8 shadow-sm">
                            <p className="text-sm font-semibold uppercase tracking-[0.24em] text-blue-600 mb-3">Visi</p>
                            <h2 className="text-2xl lg:text-3xl font-bold text-slate-900 leading-tight">{vision}</h2>
                        </div>

                        <div className="rounded-[1.75rem] border border-slate-100 bg-white p-6 lg:p-8 shadow-sm">
                            <p className="text-sm font-semibold uppercase tracking-[0.24em] text-blue-600 mb-3">Tentang Binar</p>
                            <p className="text-slate-600 leading-relaxed">
                                Berawal dari Binar Community, sebuah komunitas yang lahir dari ketulusan hati pada tanggal 11 Desember 2024, kini kami telah berkiprah lebih luas.
                                Pada tahun 2026 ini, Binar resmi menjadi yayasan dan beralih nama menjadi BINAR FOUNDATION.
                            </p>
                            <p className="mt-4 text-slate-600 leading-relaxed">
                                Berfokus pada penguatan kesehatan mental dan pendidikan untuk anak serta remaja di Indonesia, Binar hadir sebagai wadah mereka bertumbuh, sembuh, dan menjadi utuh dengan memberi dampak nyata untuk sekitar.
                            </p>
                        </div>
                    </div>

                    <div className="rounded-[1.75rem] border border-blue-50 bg-[#F4F8FF] p-6 lg:p-8 shadow-sm">
                        <div className="grid grid-cols-1 xl:grid-cols-[0.9fr_1.1fr] gap-6 items-start">
                            <div>
                                <p className="text-sm font-semibold uppercase tracking-[0.24em] text-blue-600 mb-3">Misi</p>
                                <h2 className="text-2xl lg:text-3xl font-bold text-slate-900">Langkah kerja yang terarah</h2>
                            </div>

                            <ul className="space-y-4">
                                {missions.map((mission, index) => (
                                    <li key={mission} className="flex gap-3 rounded-2xl bg-white/70 p-4 text-slate-700 leading-relaxed">
                                        <span className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-blue-600 text-sm font-bold text-white">
                                            {index + 1}
                                        </span>
                                        <span>{mission}</span>
                                    </li>
                                ))}
                            </ul>
                        </div>
                    </div>

                    <div className="rounded-[1.75rem] border border-slate-100 bg-white p-6 lg:p-8 shadow-sm">
                        <p className="text-sm font-semibold uppercase tracking-[0.24em] text-blue-600 mb-3">Makna Berbinar tuk Bersinar</p>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 lg:gap-6">
                            <div className="rounded-2xl bg-[#F8FAFC] p-5">
                                <h3 className="text-lg font-bold text-slate-900 mb-2">Berbinar</h3>
                                <p className="text-slate-600 leading-relaxed">
                                    Mengekspresikan emosi yang mendalam, penuh kejujuran, keindahan, dan tulus apa adanya. Juga tentang kesedihan yang diiringi penerimaan untuk menuju kebahagiaan.
                                </p>
                            </div>
                            <div className="rounded-2xl bg-[#F8FAFC] p-5">
                                <h3 className="text-lg font-bold text-slate-900 mb-2">Bersinar</h3>
                                <p className="text-slate-600 leading-relaxed">
                                    Tentang diri yang selalu ingin bertumbuh dan menumbuhkan yang lain, berdaya dan memberdayakan sekitar.
                                </p>
                            </div>
                        </div>
                    </div>

                    <div className="rounded-[1.75rem] border border-slate-100 bg-white p-6 lg:p-8 shadow-sm">
                        <div className="flex items-center justify-between gap-4 mb-6">
                            <div>
                                <p className="text-sm font-semibold uppercase tracking-[0.24em] text-blue-600 mb-3">Core Values</p>
                                <h2 className="text-2xl lg:text-3xl font-bold text-slate-900">Pedoman yang menjaga arah gerakan</h2>
                            </div>
                            <ArrowRight className="hidden md:block text-blue-600" size={22} />
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 lg:gap-6">
                            {values.map((value) => {
                                const Icon = value.icon;
                                return (
                                    <div key={value.title} className="rounded-2xl border border-slate-100 bg-[#F8FAFC] p-5">
                                        <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-2xl bg-blue-50 text-blue-600">
                                            <Icon size={20} />
                                        </div>
                                        <h3 className="text-lg font-bold text-slate-900">{value.title}</h3>
                                        <p className="mt-2 text-sm leading-relaxed text-slate-500">{value.description}</p>
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                </div>
            </section>
        </>
    );
};

export default AboutPage;