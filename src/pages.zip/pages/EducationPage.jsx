import { ArrowRight, BookOpenText, CalendarRange, MessageSquareQuote } from 'lucide-react';
import PageHeader from '../components/PageHeader';
import ArticlesAndRecruitment from '../page-sections/ArticlesAndRecruitment';

const educationBlocks = [
    { title: 'Artikel baru', description: 'Konten ringan untuk memahami topik kesehatan mental.', icon: BookOpenText },
    { title: 'Ruang diskusi', description: 'Bahan untuk memicu percakapan yang aman dan reflektif.', icon: MessageSquareQuote },
    { title: 'Agenda edukasi', description: 'Webinar, kelas, dan aktivitas yang dirancang rutin.', icon: CalendarRange },
];

const EducationPage = () => {
    return (
        <>
            <PageHeader
                eyebrow="Edukasi"
                title="Artikel, insight, dan ajakan untuk ikut bergerak"
                description="Bagian ini menggabungkan konten edukasi terbaru dan kesempatan bergabung bersama tim Binar."
            />

            <section className="w-full bg-white pb-8 lg:pb-12">
                <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 lg:gap-6">
                        {educationBlocks.map((block) => {
                            const Icon = block.icon;

                            return (
                                <div key={block.title} className="rounded-[1.5rem] border border-slate-100 bg-white p-5 lg:p-6 shadow-sm">
                                    <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-2xl bg-blue-50 text-blue-600">
                                        <Icon size={20} />
                                    </div>
                                    <h2 className="text-lg font-bold text-slate-900">{block.title}</h2>
                                    <p className="mt-2 text-sm leading-relaxed text-slate-500">{block.description}</p>
                                </div>
                            );
                        })}
                    </div>

                    <div className="mt-6 rounded-[2rem] border border-blue-50 bg-[#F4F8FF] p-6 lg:p-8 shadow-sm">
                        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                            <div>
                                <p className="text-sm font-semibold uppercase tracking-[0.24em] text-blue-600 mb-2">Fokus page</p>
                                <h2 className="text-2xl font-bold text-slate-900">Baca, pahami, lalu ikut bergerak</h2>
                            </div>
                            <a href="/relawan" className="inline-flex items-center justify-center rounded-full bg-blue-600 px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-blue-700">
                                Lihat Relawan <ArrowRight size={16} className="ml-2" />
                            </a>
                        </div>
                    </div>
                </div>
            </section>

            <ArticlesAndRecruitment />
        </>
    );
};

export default EducationPage;