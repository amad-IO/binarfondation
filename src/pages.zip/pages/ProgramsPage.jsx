import { useState } from 'react';
import { 
    Building2, GraduationCap, Image, MessagesSquare, Sprout, UsersRound, 
    Heart, Sparkles, Calendar, Compass, Trophy, Gift, Target, 
    HelpCircle, BookOpen, School, HandHeart, Handshake
} from 'lucide-react';
import PageHeader from '../components/PageHeader';

const DIVISIONS = [
    { title: 'Bi-Main', description: 'Membuat aturan, kebijakan, dan memastikan fasilitas untuk Bi-Family terpenuhi.', icon: Building2 },
    { title: 'Teman Sembuh', description: 'Penyediaan fasilitas dukungan kesehatan mental melalui pendekatan peer support oleh Bi-Friend.', icon: MessagesSquare },
    { title: 'Teman Tumbuh', description: 'Konten edukasi seputar kesehatan mental dan pendidikan, termasuk upgrading class untuk Bi-Family.', icon: GraduationCap },
    { title: 'Binar Goes To You', description: 'Mendampingi chapter, mengadakan pengurus chapter, dan menjembatani kolaborasi.', icon: UsersRound },
    { title: 'Med-U', description: 'Mengabadikan momen perjalanan Binar Foundation dan mempublikasikannya ke berbagai platform.', icon: Image },
];

const CHAPTERS = [
    { title: 'Binar Chapter Jatim', items: ['Rumah Belajar Kampung Pemulung', 'Rumah Belajar Gang Dolly', 'Rumah Belajar KBM Petojo'], icon: Sprout },
    { title: 'Binar Chapter Riau', items: ['Rumah Belajar Al-Muzakki'], icon: Sprout },
];

const INTERNAL_PROGRAMS = [
    { title: 'Bi-Friend', desc: 'Teman curhat sebaya yang siap menemani suka duka perjalanan kamu agar tidak berjalan sendirian.', icon: Heart, color: 'bg-rose-50 text-rose-600' },
    { title: 'Upgrading Bi-Family', desc: 'Kelas pengembangan diri (soft skills, FGD, outbonding) yang biasa disertai dengan butterfly hug.', icon: Sparkles, color: 'bg-amber-50 text-amber-600' },
    { title: 'Rapat Kenegaraan', desc: 'Rapat pembahasan program kerja yang dilaksanakan 3x dalam 1 masa periode pengurusan.', icon: Calendar, color: 'bg-indigo-50 text-indigo-600' },
    { title: 'Fun Activity', desc: 'Aktivitas menarik dan seru seperti Picnic Party, games, CFD, dan masih banyak lagi.', icon: Compass, color: 'bg-emerald-50 text-emerald-600' },
    { title: 'Binar Berprestasi', desc: 'Pendampingan intensif minat bakat seperti kelas pendampingan ajang lomba, beasiswa, dan lainnya.', icon: Trophy, color: 'bg-purple-50 text-purple-600' },
    { title: 'Anniversary Binar', desc: 'Perayaan kebahagiaan lembaran baru Binar Foundation disertai dengan Binar Awards dan Content Challenge.', icon: Gift, color: 'bg-pink-50 text-pink-600' },
    { title: 'Bi-Better', desc: 'Wadah apresiasi dan evaluasi pengurus, peri binar, dan Bi-Star untuk kebaikan bersama ke depan.', icon: Target, color: 'bg-sky-50 text-sky-600' },
];

const EXTERNAL_PROGRAMS = [
    { title: 'Konseling Gratis', desc: 'Layanan teman curhat sebaya online oleh mahasiswa/i psikologi yang berkompeten untuk Bi-Star.', icon: HelpCircle, color: 'bg-teal-50 text-teal-600' },
    { title: 'Edukasi Kesehatan Mental', desc: 'Mengedukasi Bi-star melalui konten edukatif, live instagram, podcast, hingga psikoedukasi offline.', icon: GraduationCap, color: 'bg-blue-50 text-blue-600' },
    { title: 'Mengajar Anak Marginal', desc: 'Program unggulan mendampingi adik-adik di wilayah marginal seputar kesehatan mental, karakter, dan akademik.', icon: BookOpen, color: 'bg-orange-50 text-orange-600' },
    { title: 'Binar Goes to School', desc: 'Kolaborasi dengan berbagai sekolah untuk mengedukasi siswa seputar pembentukan karakter dan kesehatan mental.', icon: School, color: 'bg-violet-50 text-violet-600' },
    { title: 'Binar Charity & Donasi', desc: 'Open donasi berkala untuk terus bertahan dan memberikan dampak nyata bagi ruang lingkup sekitar.', icon: HandHeart, color: 'bg-red-50 text-red-600' },
];

const PARTNERS = [
    { name: 'Universitas Negeri Surabaya', detail: 'Fakultas Psikologi, Sedjiwa, Putra Putri Unesa, dsb.' },
    { name: 'UIN Sunan Ampel Surabaya (UINSA)', detail: 'Kolaborasi program eksternal & akademisi' },
    { name: 'Ilimac Peduli', detail: 'Mitra aksi sosial dan keberlanjutan komunitas' },
    { name: 'Universitas Muhammadiyah Surabaya', detail: 'Sinergi riset, edukasi kesehatan mental & pengabdian' },
    { name: 'Sekolah Budaya Anak Gang Dolly Surabaya', detail: 'Lokasi implementasi program Rumah Belajar' }
];

const ProgramsPage = () => {
    const [activeTab, setActiveTab] = useState('internal');

    return (
        <>
            <PageHeader
                eyebrow="Program & Struktur"
                title="Program, divisi, dan chapter yang bergerak bersama"
                description="Halaman ini merangkum cakupan kerja Binar Foundation, dari program inti sampai struktur komunitas di daerah."
            />

            <section className="w-full bg-white pb-16 lg:pb-24">
                <div className="container mx-auto px-4 sm:px-6 lg:px-8 space-y-16 lg:space-y-24">
                    
                    {/* SECTION 1: DIVISI UTAMA */}
                    <div>
                        <div className="mb-6 lg:mb-8">
                            <p className="text-xs font-bold uppercase tracking-[0.2em] text-blue-600 mb-2">Bagian di Binar</p>
                            <h2 className="text-2xl lg:text-3xl font-extrabold text-slate-900 tracking-tight">Divisi Utama</h2>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5 lg:gap-6">
                            {DIVISIONS.map(({ title, description, icon: Icon }) => (
                                <div key={title} className="group rounded-2xl border border-slate-100 bg-slate-50/50 p-6 shadow-sm transition-all duration-200 hover:shadow-md hover:border-slate-200">
                                    <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-xl bg-blue-50 text-blue-600 transition-colors group-hover:bg-blue-100">
                                        <Icon size={20} className="stroke-[2.25]" />
                                    </div>
                                    <h3 className="text-md font-bold text-slate-900">{title}</h3>
                                    <p className="mt-2 text-sm leading-relaxed text-slate-600">{description}</p>
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* SECTION 2: PROGRAM KAMI */}
                    <div className="bg-slate-50/60 rounded-3xl p-6 lg:p-10 border border-slate-100">
                        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8">
                            <div>
                                <p className="text-xs font-bold uppercase tracking-[0.2em] text-blue-600 mb-2">Dampak Nyata</p>
                                <h2 className="text-2xl lg:text-3xl font-extrabold text-slate-900 tracking-tight">Program Kami</h2>
                            </div>
                            <div className="flex p-1 bg-slate-200/70 rounded-xl max-w-xs">
                                <button onClick={() => setActiveTab('internal')} className={`flex-1 px-4 py-2 text-sm font-semibold rounded-lg transition-all ${activeTab === 'internal' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}>
                                    Internal
                                </button>
                                <button onClick={() => setActiveTab('external')} className={`flex-1 px-4 py-2 text-sm font-semibold rounded-lg transition-all ${activeTab === 'external' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-600 hover:text-slate-900'}`}>
                                    Eksternal
                                </button>
                            </div>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
                            {(activeTab === 'internal' ? INTERNAL_PROGRAMS : EXTERNAL_PROGRAMS).map((prog) => {
                                const Icon = prog.icon;
                                return (
                                    <div key={prog.title} className="bg-white p-5 lg:p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-all duration-200 flex flex-col justify-between">
                                        <div>
                                            <div className={`mb-4 flex h-10 w-10 items-center justify-center rounded-xl ${prog.color}`}>
                                                <Icon size={18} className="stroke-[2.25]" />
                                            </div>
                                            <h3 className="text-base font-bold text-slate-900 mb-2">{prog.title}</h3>
                                            <p className="text-sm leading-relaxed text-slate-500">{prog.desc}</p>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    </div>

                    {/* SECTION 3: MITRA KOLABORASI (TAMBAHAN BARU) */}
                    <div>
                        <div className="mb-6 lg:mb-8">
                            <p className="text-xs font-bold uppercase tracking-[0.2em] text-blue-600 mb-2">Jaringan Gerakan</p>
                            <h2 className="text-2xl lg:text-3xl font-extrabold text-slate-900 tracking-tight">Mitra Kolaborasi</h2>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                            {PARTNERS.map((partner, index) => (
                                <div key={index} className="flex gap-4 p-5 rounded-2xl border border-slate-100 bg-white shadow-sm items-start">
                                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-emerald-50 text-emerald-600">
                                        <Handshake size={20} />
                                    </div>
                                    <div>
                                        <h4 className="text-sm font-bold text-slate-950 leading-snug">{partner.name}</h4>
                                        <p className="text-xs text-slate-500 mt-1 leading-relaxed">{partner.detail}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* SECTION 4: CHAPTER & PERLUASAN */}
                    <div className="rounded-3xl border border-blue-50 bg-blue-50/30 p-6 lg:p-10 shadow-sm">
                        <div className="mb-6">
                            <p className="text-xs font-bold uppercase tracking-[0.2em] text-blue-600 mb-2">Chapter</p>
                            <h2 className="text-2xl lg:text-3xl font-extrabold text-slate-900 tracking-tight">Perluasan Gerakan ke Daerah</h2>
                        </div>
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 lg:gap-6">
                            {CHAPTERS.map(({ title, items, icon: Icon }) => (
                                <div key={title} className="rounded-2xl bg-white p-6 border border-slate-100 shadow-sm">
                                    <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-xl bg-blue-50 text-blue-600">
                                        <Icon size={20} className="stroke-[2.25]" />
                                    </div>
                                    <h3 className="text-md font-bold text-slate-900 mb-4">{title}</h3>
                                    <ul className="space-y-3 text-sm text-slate-600">
                                        {items.map((item) => (
                                            <li key={item} className="flex items-start gap-3">
                                                <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-blue-500" />
                                                <span className="leading-normal">{item}</span>
                                            </li>
                                        ))}
                                    </ul>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </section>
        </>
    );
};

export default ProgramsPage;